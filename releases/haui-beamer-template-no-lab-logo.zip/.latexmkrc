# Overleaf / latexmk: biên dịch bằng XeLaTeX
$pdf_mode = 5;
$xelatex = 'xelatex -interaction=nonstopmode -synctex=1 %O %S';
